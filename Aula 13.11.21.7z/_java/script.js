function positivo() {
    window.location.assign("formulario.html");
}

function negativo() {
    alert("Você não pode participar da promoção atualmente !");
}